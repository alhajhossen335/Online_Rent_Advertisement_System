# OnlineRentAdvertisementSystem
Frontend and Backend : HTML, CSS, Bootstrap,JavaScript,PHP; Database: MySql
